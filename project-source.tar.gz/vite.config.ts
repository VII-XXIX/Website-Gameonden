
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        about: resolve(__dirname, 'about.html'),
        games: resolve(__dirname, 'games.html'),
        pricing: resolve(__dirname, 'pricing.html'),
        'book-slot': resolve(__dirname, 'book-slot.html'),
        contact: resolve(__dirname, 'contact.html'),
      },
    },
  },
});
